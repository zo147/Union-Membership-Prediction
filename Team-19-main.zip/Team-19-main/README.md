# Team-19
 Team 19's group project GitHub repository for MGT 6203 (Canvas) Spring of 2024 semester.

# Instructions for Use:

- Dataset is stored in the 'Data' folder (censusdata.csv).
- 'Code' folder is the other one of interest. 
- The final version of the project can be run from start to finish in the ***'finalModel.Rmd'*** R-markdown file within the Code folder. 
  - All necessary libraries are loaded in the top section of the Rmd file. If a library is not installed on your machine, use the code install.packages('*libraryname*').
  - Any other code files in this folder may be out of date with the final project results.
- All other folders are not useful for review.

- Have fun reviewing Labor Union Membership Prediction From Census Data!!
